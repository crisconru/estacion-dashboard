package angelo.itl.arduinoairqualitymonitor.web;

/**
 * Created by Angelo on 14/12/2016.
 */

public enum ConnectionStatus {
    CONNECTED, DISCONNECTED, LOST, CANNOT_CONNECT, IP_PORT_ERROR, INPUT_ERROR, INTERNET_DISCONNECTED, NO_ROUTE_TO_HOST
}
